"use strict";

/*
   New Perspectives on HTML5 and CSS3, 8th Edition
   Tutorial 10
   Case Problem 1

   Author: Mallory Price
   Date: 02/02/2026  
   
   Filename: tc_cart.js
	
*/

/*
Name: Your Name
Date: February 2, 2026
*/

/* Step 10 */
var orderTotal = 0;

/* Step 11 */
var cartHTML = "<table>" +
  "<tr>" +
  "<th>Item</th>" +
  "<th>Description</th>" +
  "<th>Price</th>" +
  "<th>Qty</th>" +
  "<th>Total</th>" +
  "</tr>";

/* Step 12 */
for (var i = 0; i < item.length; i++) {

  /* Step 12a */
  cartHTML += "<tr>" +
    "<td><img src='tc_item.png' alt='" + item[i] + "' /></td>";

  /* Step 12b */
  cartHTML += "<td>" + itemDescription[i] + "</td>" +
    "<td>$" + itemPrice[i].toFixed(2) + "</td>" +
    "<td>" + itemQty[i] + "</td>";

  /* Step 12c */
  var itemCost = itemPrice[i] * itemQty[i];

  /* Step 12d */
  cartHTML += "<td>$" + itemCost.toFixed(2) + "</td></tr>";

  /* Step 12e */
  orderTotal += itemCost;
}

/* Step 13 */
cartHTML += "<tr>" +
  "<td colspan='4'>Subtotal</td>" +
  "<td>$" + orderTotal.toFixed(2) + "</td>" +
  "</tr></table>";

/* Step 14 */
document.getElementById("cart").innerHTML = cartHTML;
