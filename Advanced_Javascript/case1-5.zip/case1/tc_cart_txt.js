"use strict";

/*
   New Perspectives on HTML5 and CSS3, 8th Edition
   Tutorial 10
   Case Problem 1

   Author: Mallory Price
   Date: 02/02/2026  
   
   Filename: tc_cart.js
	
*/

