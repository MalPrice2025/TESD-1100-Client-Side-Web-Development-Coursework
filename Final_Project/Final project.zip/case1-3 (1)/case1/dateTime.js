"use strict"
/*
Author: Mallory Price
Date: 02/03/2026

Filename: dateTime.js
*/

setInterval("runClock()", 1000);
runClock();

function runClock() {
var thisDay = new Date();
var thisDate = thisDay.toLocaleDateString();
var thisTime = thisDay.toLocaleTimeString();

document.getElementById("date").textContent = thisDate;
document.getElementById("time").textContent = thisTime;
}